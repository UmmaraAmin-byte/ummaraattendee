import 'package:flutter/material.dart';
import '../../services/auth_service.dart';
import '../../models/user_model.dart';
import '../profile_screen.dart';
import 'attendee_dashboard.dart';

class StaffDashboard extends StatefulWidget {
  const StaffDashboard({super.key});

  @override
  State<StaffDashboard> createState() => _StaffDashboardState();
}

class _StaffDashboardState extends State<StaffDashboard> {
  final _auth = AuthService();
  bool _redirecting = false;
  final _buildingNameCtrl = TextEditingController();
  final _buildingAddressCtrl = TextEditingController();
  final _buildingDescCtrl = TextEditingController();
  final _roomNameCtrl = TextEditingController();
  final _roomCapacityCtrl = TextEditingController();
  final _roomAmenitiesCtrl = TextEditingController();
  final _roomPricingCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _guardAuth();
  }

  void _guardAuth() {
    final user = _auth.currentUser;
    if (_redirecting) return;
    if (user == null || user.role != UserRole.staff) {
      _redirecting = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const AttendeeDashboard()),
          (r) => false,
        );
      });
    }
  }

  @override
  void dispose() {
    _buildingNameCtrl.dispose();
    _buildingAddressCtrl.dispose();
    _buildingDescCtrl.dispose();
    _roomNameCtrl.dispose();
    _roomCapacityCtrl.dispose();
    _roomAmenitiesCtrl.dispose();
    _roomPricingCtrl.dispose();
    super.dispose();
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? Colors.redAccent : const Color(0xFF2D2D2D),
    ));
  }

  InputDecoration _inputDeco(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Color(0xFF6B6B6B)),
      prefixIcon: Icon(icon, color: const Color(0xFF2D2D2D), size: 20),
    );
  }

  Future<void> _pickAndAddAvailability(String roomId) async {
    final now = DateTime.now();
    final date = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: now,
      lastDate: DateTime(now.year + 2),
    );
    if (!mounted) return;
    if (date == null) return;
    final startTime = await showTimePicker(
      context: context,
      initialTime: const TimeOfDay(hour: 9, minute: 0),
    );
    if (!mounted) return;
    if (startTime == null) return;
    final endTime = await showTimePicker(
      context: context,
      initialTime: const TimeOfDay(hour: 12, minute: 0),
    );
    if (!mounted) return;
    if (endTime == null) return;

    final start = DateTime(
      date.year,
      date.month,
      date.day,
      startTime.hour,
      startTime.minute,
    );
    final end = DateTime(
      date.year,
      date.month,
      date.day,
      endTime.hour,
      endTime.minute,
    );
    final err = _auth.addAvailability(roomId: roomId, start: start, end: end);
    if (err != null) {
      _showSnack(err, isError: true);
      return;
    }
    setState(() {});
    _showSnack('Availability added.');
  }

  void _showAddBuildingDialog() {
    _buildingNameCtrl.clear();
    _buildingAddressCtrl.clear();
    _buildingDescCtrl.clear();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFFFFFFFF),
        title: const Text('Add Building'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _buildingNameCtrl,
              decoration: _inputDeco('Building Name', Icons.apartment_outlined),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _buildingAddressCtrl,
              decoration: _inputDeco('Address', Icons.location_on_outlined),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _buildingDescCtrl,
              maxLines: 2,
              decoration: _inputDeco('Description', Icons.notes_outlined),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final err = _auth.addBuilding(
                name: _buildingNameCtrl.text,
                address: _buildingAddressCtrl.text,
                description: _buildingDescCtrl.text,
              );
              if (err != null) {
                _showSnack(err, isError: true);
                return;
              }
              Navigator.pop(context);
              setState(() {});
              _showSnack('Building added.');
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showAddRoomDialog(String buildingId) {
    _roomNameCtrl.clear();
    _roomCapacityCtrl.clear();
    _roomAmenitiesCtrl.clear();
    _roomPricingCtrl.clear();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFFFFFFFF),
        title: const Text('Add Room'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _roomNameCtrl,
                decoration: _inputDeco('Room Name', Icons.meeting_room_outlined),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _roomCapacityCtrl,
                keyboardType: TextInputType.number,
                decoration: _inputDeco('Capacity', Icons.people_outline),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _roomAmenitiesCtrl,
                decoration: _inputDeco(
                  'Amenities (comma separated)',
                  Icons.checklist_rtl_outlined,
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _roomPricingCtrl,
                keyboardType: TextInputType.number,
                decoration: _inputDeco('Pricing (optional)', Icons.payments_outlined),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final capacity = int.tryParse(_roomCapacityCtrl.text.trim()) ?? 0;
              final pricing = double.tryParse(_roomPricingCtrl.text.trim());
              final amenities = _roomAmenitiesCtrl.text
                  .split(',')
                  .map((a) => a.trim())
                  .where((a) => a.isNotEmpty)
                  .toList();
              final err = _auth.addRoom(
                buildingId: buildingId,
                name: _roomNameCtrl.text,
                capacity: capacity,
                amenities: amenities,
                pricing: pricing,
              );
              if (err != null) {
                _showSnack(err, isError: true);
                return;
              }
              Navigator.pop(context);
              setState(() {});
              _showSnack('Room added.');
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = _auth.currentUser!;
    final buildingIds = _auth.ownerBuildings.map((b) => b['id']).toSet();
    final totalRooms =
        _auth.allRooms.where((r) => buildingIds.contains(r['buildingId'])).length;

    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFA),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFFFFFF),
        elevation: 0,
        title: const Text(
          'Venue Owner',
          style: TextStyle(
            color: Color(0xFF1A1A1A),
            fontWeight: FontWeight.w700,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_outline, color: Color(0xFF1A1A1A)),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ProfileScreen()),
            ).then((_) => setState(() {})),
          ),
          IconButton(
            icon: const Icon(Icons.logout_rounded, color: Color(0xFF1A1A1A)),
            onPressed: () {
              _auth.logout();
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const AttendeeDashboard()),
                (r) => false,
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Hi, ${user.fullName}',
              style: const TextStyle(
                color: Color(0xFF1A1A1A),
                fontSize: 22,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'Manage buildings, rooms, and availability',
              style: TextStyle(color: Color(0xFF6B6B6B)),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(child: _stat('Buildings', '${_auth.ownerBuildings.length}')),
                const SizedBox(width: 10),
                Expanded(child: _stat('Rooms', '$totalRooms')),
              ],
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _showAddBuildingDialog,
              icon: const Icon(Icons.add_business_outlined),
              label: const Text('Add Building'),
            ),
            const SizedBox(height: 16),
            if (_auth.ownerBuildings.isEmpty)
              _emptyState('No buildings yet. Add your first building.')
            else
              ..._auth.ownerBuildings.map((b) {
                final rooms = _auth.roomsForBuilding(b['id'] as String);
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFFFFF),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFFE8E8E8)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              b['name'] as String,
                              style: const TextStyle(
                                color: Color(0xFF1A1A1A),
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          IconButton(
                            onPressed: () {
                              final err = _auth.deleteBuilding(b['id'] as String);
                              if (err != null) {
                                _showSnack(err, isError: true);
                                return;
                              }
                              setState(() {});
                            },
                            icon: const Icon(Icons.delete_outline, color: Color(0xFF6B6B6B)),
                          ),
                        ],
                      ),
                      Text(
                        b['address'] as String,
                        style: const TextStyle(color: Color(0xFF6B6B6B), fontSize: 12),
                      ),
                      const SizedBox(height: 8),
                      OutlinedButton.icon(
                        onPressed: () => _showAddRoomDialog(b['id'] as String),
                        icon: const Icon(Icons.add),
                        label: const Text('Add Room'),
                      ),
                      ...rooms.map((r) {
                        final slots = _auth.availabilityForRoom(r['id'] as String);
                        return Container(
                          margin: const EdgeInsets.only(top: 8),
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF2F2F2),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  '${r['name']} · cap ${r['capacity']} · slots ${slots.length}',
                                  style: const TextStyle(color: Color(0xFF1A1A1A), fontSize: 12),
                                ),
                              ),
                              TextButton(
                                onPressed: () => _pickAndAddAvailability(r['id'] as String),
                                child: const Text('Add Slot'),
                              ),
                            ],
                          ),
                        );
                      }),
                    ],
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  Widget _stat(String label, String value) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFFFF),
        border: Border.all(color: const Color(0xFFE8E8E8)),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            value,
            style: const TextStyle(
              color: Color(0xFF1A1A1A),
              fontSize: 22,
              fontWeight: FontWeight.w700,
            ),
          ),
          Text(label, style: const TextStyle(color: Color(0xFF6B6B6B))),
        ],
      ),
    );
  }

  Widget _emptyState(String msg) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Text(
          msg,
          style: const TextStyle(color: Color(0xFF6B6B6B)),
        ),
      ),
    );
  }
}
